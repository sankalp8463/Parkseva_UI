export const environment = {
  production: false,
  apiUrl: 'http://localhost:3000',
  appName: 'ParkEase',
  version: '1.0.0'
};